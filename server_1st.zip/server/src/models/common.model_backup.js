import query from '../config/db-connection.js';
import utils from '../utils/common.utils.js';

class CommonModel {
    find = async (tableName, params = {}, order_by = {}, selectColumns = '*') => {
        let sql = `SELECT ${selectColumns} FROM ${tableName}`;

        if (!Object.keys(params).length) {
            return await query(sql);
        }

        const {columnSet, values} = utils.multipleSearchColumnSet(params)
        sql += ` WHERE ${columnSet}`;
        if (Object.keys(order_by).length) {
            sql += ` ORDER BY ${Object.keys(order_by)[0]} ${Object.values(order_by)[0]}`
        }
        return await query(sql, [...values]);
    }

    findOne = async (tableName, params, selectColumns = undefined) => {
        const {columnSet, values} = utils.multipleSearchColumnSet(params)

        const sql = `SELECT ${selectColumns == undefined ? '*' : selectColumns} FROM ${tableName}
        WHERE ${columnSet}`;

        const result = await query(sql, [...values]);

        // return back the first row (user)
        return result[0];
    }

    update = async (tableName, params, id) => {
        const {columnSet, values} = utils.multipleColumnSet(params)

        const sql = `UPDATE ${tableName} SET ${columnSet} WHERE id = ?`;
        const result = await query(sql, [...values, id]);

        return result;
    }

    // check_in = async (tableName, employee_id) => {
    //     const sql = `INSERT INTO ${tableName}
    //     (employee_id,status)VALUES(?,?)`
    //
    //     const result = await query(sql, [employee_id, 'checkIn']);
    //     const affectedRows = result ? result.affectedRows : 0;
    //
    //     return affectedRows;
    // }

    timestamp = async (tableName,employee_id,method,status) => {
        if (method === "ADD"){
            const insertSql = `INSERT INTO ${tableName} (employee_id, status) VALUES (?, ?)`;
            const selectSql = `SELECT * FROM ${tableName} WHERE id = LAST_INSERT_ID()`;

            const insertResult = await query(insertSql, [employee_id, status]);
            const newRowId = insertResult ? insertResult.insertId : 0;

            if (newRowId) {
                const selectResult = await query(selectSql);
                return selectResult[0];
            }

            return null;
        }else{
            const updateSql = `UPDATE ${tableName} SET check_out = CURRENT_TIMESTAMP,status = ? WHERE employee_id = ?`;
            const selectSql = `SELECT * FROM ${tableName} WHERE employee_id = ?`;

            const updateResult = await query(updateSql, [status,employee_id]);

            if (updateResult.affectedRows > 0) {
                const selectResult = await query(selectSql, [employee_id]);
                return selectResult[0];
            }

            return null;
        }
    }

    check_in = async (tableName, employee_id,status) => {
        const insertSql = `INSERT INTO ${tableName} (employee_id, status) VALUES (?, ?)`;
        const selectSql = `SELECT * FROM ${tableName} WHERE id = LAST_INSERT_ID()`;

        const insertResult = await query(insertSql, [employee_id, status]);
        const newRowId = insertResult ? insertResult.insertId : 0;

        if (newRowId) {
            const selectResult = await query(selectSql);
            return selectResult[0];
        }

        return null;
    }

    check_out = async (tableName, employee_id) => {
        const updateSql = `UPDATE ${tableName} SET check_out = CURRENT_TIMESTAMP,status = ? WHERE employee_id = ?`;
        const selectSql = `SELECT * FROM ${tableName} WHERE employee_id = ?`;

        const updateResult = await query(updateSql, ['checkOut',employee_id]);

        if (updateResult.affectedRows > 0) {
            const selectResult = await query(selectSql, [employee_id]);
            return selectResult[0];
        }

        return null;
    }




    check_out1 = async (tableName, employee_id) => {
        const sql = `UPDATE ${tableName} SET check_out = CURRENT_TIMESTAMP,status = 'checkOut' WHERE employee_id = ? AND check_out IS NULL`;

        const result = await query(sql, [employee_id]);
        const affectedRows = result ? result.affectedRows : 0;

        return affectedRows;
    }

    work_hours = async (tableName, employeeId, date) => {
        const startDate = `${date} 00:00:00`;
        const endDate = `${date} 23:59:59`;

        let sql = `SELECT check_in, check_out, status FROM ${tableName} WHERE employee_id = ? AND check_in BETWEEN ? AND ?`;

        return await query(sql, [employeeId, startDate, endDate]);
    }

}

export default new CommonModel;