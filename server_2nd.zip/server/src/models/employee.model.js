import query from '../config/db-connection.js';
import commonModel from "./common.model.js";

class EmployeeModel {
    tableName = `attendance`;
    breakTable = `break_in_out`;

    timestamp = async (employee_id,method,status) => {
        return await commonModel.timestamp(this.tableName, employee_id,method,status);
    }
    
    in = async (employee_id) => {
        return await commonModel.in(this.tableName, employee_id);
    }

    out = async (employee_id) => {
        return await commonModel.out(this.tableName, employee_id);
    }

    work_hours = async (employeeId, date) => {
        return await commonModel.work_hours(this.tableName,employeeId, date);
    }

    check_work_hours = async (employeeId, date) => {
        let check = await commonModel.work_hours(this.tableName,employeeId, date);
        let breakin = [];
        if (check.length > 0){
            check = check[check.length - 1];
            breakin = await commonModel.work_hours(this.breakTable,employeeId, date);
        }else{
            check = [];
        }
        return {
            "check":check,
            "breakin":breakin
        };
    }


    work_hours_all = async (employeeId, date) => {
        const startDate = `${date} 00:00:00`;
        const endDate = `${date} 23:59:59`;

        let sql = `SELECT in, out, status FROM ${this.tableName} WHERE employee_id = ? AND in BETWEEN ? AND ?`;

        return await query(sql, [employeeId, startDate, endDate]);
    };

    calculateDuration = async (checkIn, checkOut) => {
        // const sql = 'SELECT TIMEDIFF(?, ?) AS duration';
        // const result = await query(sql, [checkOut, checkIn]);
        // return result[0].duration;

        const durationInMillis = checkOut.getTime() - checkIn.getTime();
        const durationInHours = durationInMillis / (1000 * 60 * 60);
        return durationInHours.toString();
    }

    findOne = async (params) => {
        return await commonModel.findOne(this.tableName, params);
    }

    checkInStatus = async () => {

    }


}

export default new EmployeeModel;