import {calculateDuration} from '../utils/function.js'
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import AuthModel from '../models/auth.model.js';
import EmployeeModel from '../models/employee.model.js';
import BreakModel from "../models/break.model.js";


/******************************************************************************
 *                             Employee Controller
 ******************************************************************************/

class EmployeeController {
    login = async (req, res, next) => {
        const {email, password: pass} = req.body;

        console.log(email);
        const user = await AuthModel.findOne({email});

        if (!user) {
            res.status(400).send({message: 'Incorrect email or password.'});
            return;
        }

        const isMatch = await bcrypt.compare(pass, user.password)
        if (!isMatch) {
            res.status(400).send({message: 'Incorrect email or password.'});
            return;
        }

        // user matched
        const secretKey = process.env.SECRET_JWT || "";
        const token = jwt.sign({user_id: user.id.toString()}, secretKey, {
            expiresIn: '2d'
        });

        const {password, created_at, updated_at, ...userWithoutPassword} = user;
        res.status(200).send({...userWithoutPassword, token});
    };

    edit = async (req, res, next) => {
        console.log(req.files[0].filename);

        const id = req.currentUser.id;

        const user = await AuthModel.findOne({id});
        if (user.role !== 'Employee' || user.status !== 'Active') {
            res.status(401).send({message: 'you have not permission to edit'});
        }
        // req.body.updated_at = CURRENT_TIMESTAMP
        req.body.updated_at = new Date();
        console.log(req.body);

        // const result = await AuthModel.update(req.body, req.currentUser.id);
        // res.send(result)

    };

    timestamp = async (req, res, next) => {
        const tableAction = req.body.action;

        const employee_id = req.currentUser.id
        let result;

        if (tableAction === "check") {
            result = await EmployeeModel.timestamp(employee_id, req.body.method, req.body.status);
        } else {
            result = await BreakModel.timestamp(employee_id, req.body.method, req.body.status);
        }
        if (!result) {
            return res.status(400).json({message: 'Something went wrong'});
        }
        res.send(result);
    };

    in1 = async (req, res, next) => {
        const employee_id = req.currentUser.id
        const result = await EmployeeModel.in(employee_id);

        if (!result) {
            return res.status(400).json({message: 'Something went wrong'});
        }
        res.send({
            data: result,
            message: 'Check in successfully !'
        });
    };

    out = async (req, res, next) => {
        const employee_id = req.currentUser.id
        const result = await EmployeeModel.out(employee_id);

        if (!result) {
            return res.status(400).json({message: 'Something went wrong'});
        }
        res.send({
            data: result,
            message: 'Check out successfully !'
        });

        //res.status(200).send({message: 'Check out successfully !'});
    };

    checkAttendance = async (req, res, next) => {
        const date = new Date();
        const dateString = date.toISOString();
        const [datePart] = dateString.split("T");
        try {
            const employeeId = req.currentUser.id;
            const date = datePart;
            // const date = "2023-07-04";

            const result = await EmployeeModel.work_hours(employeeId, date);

            let workingHours = 0;
            let minimumWorkingHours = 12;

            for (const row of result) {

                const checkIn = new Date(row._in);
                const checkOut = row._out ? new Date(row._out) : new Date();

                const duration = await EmployeeModel.calculateDuration(checkIn, checkOut);

                // Extract hours from the duration string (format: HH:MM:SS)
                const [hours] = duration.split(':');
                workingHours += parseFloat(hours);
            }

            // const currentTime = new Date();
            // const latestCheckIn = result.length > 0 ? new Date(result[result.length - 1].in) : null;

            // if (latestCheckIn && latestCheckIn.toDateString() === currentTime.toDateString()) {
            //     // User has a check-in entry for the current day
            //     const duration = (currentTime - latestCheckIn) / 1000 / 60 / 60; // Duration in hours
            //     workingHours += duration;
            // }
            let remainWorkingHours = minimumWorkingHours - workingHours;

            res.json({employeeId, date, minimumWorkingHours, workingHours, remainWorkingHours});
        } catch (err) {
            console.log('Error in getting attending details', err.message);
        }
    };

    checkAllAttendance = async (req, res, next) => {
        try {
            // const employeeIds = req.body.employeeIds;
            // const date = req.body.date;
            const employeeIds = ["c39bf89d-9613-44bc-baab-9878ca4bc56b", "8192f06b-9e76-4abb-8183-e24c682aa0e5"];
            const date = "2023/07/04";

            const resultPromises = employeeIds.map(async (employeeId) => {
                const result = await EmployeeModel.work_hours_all(employeeId, date);
                return result;
            });

            const results = await Promise.all(resultPromises);

            let attendanceDetails = [];

            for (let i = 0; i < results.length; i++) {
                let workingHours = 0;
                let minimumWorkingHours = 12;

                const result = results[i];

                for (const row of result) {
                    const checkIn = new Date(row.in);
                    const checkOut = row.out ? new Date(row.out) : new Date();

                    const duration = await calculateDuration(checkIn, checkOut);

                    // Extract hours from the duration string (format: HH:MM:SS)
                    const [hours] = duration.split(':');
                    workingHours += parseFloat(hours);
                }

                const currentTime = new Date();
                const latestCheckIn = result.length > 0 ? new Date(result[result.length - 1].in) : null;

                if (latestCheckIn && latestCheckIn.toDateString() === currentTime.toDateString()) {
                    // User has a check-in entry for the current day
                    const duration = (currentTime - latestCheckIn) / 1000 / 60 / 60; // Duration in hours
                    workingHours += duration;
                }

                let remainWorkingHours = minimumWorkingHours - workingHours;

                const attendanceData = {
                    employeeId: employeeIds[i],
                    date,
                    minimumWorkingHours,
                    workingHours,
                    remainWorkingHours,
                };

                attendanceDetails.push(attendanceData);
            }
            // console.log(attendanceDetails)
            res.json({attendanceDetails});
        } catch (err) {
            console.log('Error in getting attending details', err.message);
        }
    };

    checkInStatus = async (req, res, next) => {
        const date = new Date();
        const dateString = date.toISOString();
        const [datePart] = dateString.split("T");

        try {
            const employeeId = req.currentUser.id;
            // const date = '2023-07-05';
            const date = datePart;

            let result = await EmployeeModel.check_work_hours(employeeId, date);
            console.log({result})
            if (result.check !== undefined && result.check.length !== 0) {
                console.log("if")
                res.send(result);
            } else {
                console.log("else")
                res.send({
                    "check": {
                        "in": null,
                        "out": null,
                        "status": "CheckOut"
                    },
                    "breakin": []
                });
            }

            // if(result.length>0){
            //     result = result[result.length - 1];
            //
            // }else{
            //     const result = {
            //         "in": null,
            //         "out": null,
            //         "status": "CheckOut"
            //     }
            //     res.send(result);
            // }
        } catch (err) {
            console.log('Error in getting check-in status:', err.message);
            res.status(400).json({error: 'Failed to fetch check-in status'});
        }
    };

    total_work = async (req, res, next) => {

    }

    break_in = async (req, res, next) => {
        const employee_id = req.currentUser.id
        const result = await BreakModel.in(employee_id, "breakIn");

        if (!result) {
            return res.status(400).json({message: 'Something went wrong'});
        }
        res.send({
            data: result,
            message: 'break in successfully !'
        });
    };

    break_out = async (req, res, next) => {
        const employee_id = req.currentUser.id
        const result = await BreakModel.out(employee_id);

        if (!result) {
            return res.status(400).json({message: 'Something went wrong'});
        }
        res.send({
            data: result,
            message: 'break out successfully !'
        });
    };

    break_calculation = async (req, res, next) => {
        const date = new Date();
        const dateString = date.toISOString();
        const [datePart] = dateString.split("T");
        try {
            const employeeId = req.currentUser.id;
            const date = datePart;
            // const date = "2023-07-04";

            const result = await BreakModel.work_hours(employeeId, date);

            let brakeTimeHours = 0;

            for (const row of result) {

                const checkIn = new Date(row._in);
                const checkOut = row._out ? new Date(row._out) : new Date();

                const duration = await EmployeeModel.calculateDuration(checkIn, checkOut);
                console.log({duration})
                // Extract hours from the duration string (format: HH:MM:SS)
                const [hours] = duration.split(':');
                brakeTimeHours += parseFloat(hours);
            }
            const currentTime = new Date();
            const latestCheckIn = result.length > 0 ? new Date(result[result.length - 1].in) : null;
            // if (latestCheckIn && latestCheckIn.toDateString() === currentTime.toDateString()) {
            //     // User has a check-in entry for the current day
            //     const duration = (currentTime - latestCheckIn) / 1000 / 60 / 60; // Duration in hours
            //     brakeTimeHours = duration;
            // }
            console.log(brakeTimeHours)
            res.json({employeeId, date, brakeTimeHours});
        } catch (err) {
            console.log('Error in getting attending details', err.message);
        }
    }

    break_status = async (req, res, next) => {
        const date = new Date();
        const dateString = date.toISOString();
        const [datePart] = dateString.split("T");

        try {
            const employeeId = req.currentUser.id;
            // const date = '2023-07-05';
            const date = datePart;

            let result = await BreakModel.work_hours(employeeId, date);
            result = result[result.length - 1];
            res.status(200).send(result)
        } catch (err) {
            console.log('Error in getting check-in status:', err.message);
            res.status(400).json({error: 'Failed to fetch check-in status'});
        }
    };

}


/******************************************************************************
 *                               Export
 ******************************************************************************/
export default new EmployeeController;